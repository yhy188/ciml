release_questions <- function() {
  c('Have you checked all the items in Evernote-LTMLE release process?') # nocov
}
