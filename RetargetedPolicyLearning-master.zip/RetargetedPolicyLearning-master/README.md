# RetargetedPolicyLearning

Replication code for "More Efficient Policy Learning via Optimal Retargeting"
https://arxiv.org/abs/1906.08611

To produce Figures 1--3, run synthetic_experiments.R.
To produce Table 1, run job_policy.R.
